import { Component } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController, LoadingController, Loading } from 'ionic-angular';
import { InsertInfoProvider } from '../../providers/insert-info/insert-info';
import { LoginPage } from '../login/login';
/**
 * Generated class for the InsertInfoPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@IonicPage()
@Component({
  selector: 'page-insert-info',
  templateUrl: 'insert-info.html',
})
export class InsertInfoPage {
  loading: Loading;
  locations:any[];
  optionsList:any[];
  registerCredentials = {date:''};
  constructor(public navCtrl: NavController, public navParams: NavParams, private insertInfo: InsertInfoProvider, private alertCtrl: AlertController, private loadingCtrl: LoadingController) {
  }

  ionViewDidLoad() {
    if(localStorage.getItem("userName") !== null){
      this.showLoading();
      this.insertInfo.getInfo().subscribe(allowed => {
      this.loading.dismiss();
        if (allowed.status == 'Success') {        
         // this.nav.push(HomePage);
         this.optionsList = allowed.data;
         this.locations = allowed.locations;
          this.showError(allowed);
       // this.navCtrl.setRoot(InsertInfoPage); 
        } else {
          this.showError(allowed);
        }
      },
        error => {
          this.showError('error');
       });
    }
    else{
      localStorage.clear();
      this.navCtrl.setRoot(LoginPage);
    }
  }

  signOut(){
    localStorage.clear();
    this.navCtrl.setRoot(LoginPage);
  }
  showLoading() {
    this.loading = this.loadingCtrl.create({
      content: 'Please wait...',
      dismissOnPageChange: true
    });
    this.loading.present();
  }

  showError(allowed) {
    this.loading.dismiss();
    let alert = this.alertCtrl.create({
      title: allowed.title,
      subTitle: allowed.subTitle,
      buttons: ['OK']
    });
    alert.present();
  }
}
